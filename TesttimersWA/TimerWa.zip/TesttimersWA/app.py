from flask import Flask, jsonify
import logging
import random
import time
import threading
import requests
from datetime import datetime, timedelta
import uuid
import io

app = Flask(__name__)
logging.basicConfig(level=logging.INFO)

# Hardcoded configuration variables
UPLOAD_URL = "https://resumefinalproj.azurewebsites.net/upload_resume"

# Log initialization
logging.info("Starting ResumeUploaderWeb...")

def process_single_request():
    try:
        # Generate a sample resume (simulating a PDF file)
        candidate_id = str(uuid.uuid4())
        email = "jaluterman99@gmail.com"
        # Simulate a small PDF-like content (in reality, this would be a real PDF file)
        sample_pdf_content = b"%PDF-1.4\n%Sample resume content with skills: Python, Azure.\n%%EOF"
        file_name = f"resume_{candidate_id[:8]}.pdf"

        logging.info(f"Generated sample resume for {email} with ID {candidate_id}.")

        # Prepare the multipart form data
        files = {
            'resume': (file_name, io.BytesIO(sample_pdf_content), 'application/pdf')
        }
        data = {
            'email': email
        }

        # Call the ResumeUploadUI endpoint
        logging.info(f"Sending resume to {UPLOAD_URL} for {email}...")
        upload_response = requests.post(
            UPLOAD_URL,
            files=files,
            data=data
        )
        upload_response.raise_for_status()
        logging.info(f"Resume uploaded to ResumeUploadUI: {upload_response.status_code} - {upload_response.text}")

    except Exception as e:
        logging.error(f"Error processing request: {str(e)}")

def upload_resume_task():
    burst_hour = None
    last_day = None

    while True:
        try:
            now = datetime.now()
            current_day = now.date()
            current_hour = now.hour

            # At the start of a new day (midnight), select a new burst hour
            if last_day != current_day:
                burst_hour = random.randint(0, 23)  # Random hour between 0 (12 AM) and 23 (11 PM)
                last_day = current_day
                logging.info(f"Selected burst hour for {current_day}: {burst_hour}:00")

            # Calculate the time until the next hour
            next_hour = (now.replace(minute=0, second=0, microsecond=0) + timedelta(hours=1))
            seconds_until_next_hour = (next_hour - now).total_seconds()

            # Sleep until the next hour
            logging.info(f"Sleeping for {seconds_until_next_hour} seconds until the next hour.")
            time.sleep(seconds_until_next_hour)

            # Determine if this is the burst hour
            now = datetime.now()
            is_burst_hour = (now.hour == burst_hour)

            if is_burst_hour:
                # Burst hour: Process 1001 requests (1 regular + 1000 additional)
                num_requests = 1000
                logging.info(f"Burst hour {now.hour}:00: Processing {num_requests} requests.")
                # Generate random times within this hour (in seconds, 0-3599)
                request_times = sorted([random.randint(0, 3599) for _ in range(num_requests)])
                start_time = now.replace(minute=0, second=0, microsecond=0)
                for i, delay in enumerate(request_times):
                    # Calculate time until this request
                    current_time = datetime.now()
                    target_time = start_time + timedelta(seconds=delay)
                    sleep_seconds = (target_time - current_time).total_seconds()
                    if sleep_seconds > 0:
                        logging.info(f"Request {i+1}/{num_requests}: Sleeping for {sleep_seconds} seconds until {target_time.strftime('%H:%M:%S')}.")
                        time.sleep(sleep_seconds)
                    process_single_request()
            else:
                # Normal hour: Process 1 request at a random minute
                random_minute = random.randint(0, 59)
                delay_seconds = random_minute * 60
                logging.info(f"Normal hour {now.hour}:00: Delaying execution by {random_minute} minutes ({delay_seconds} seconds).")
                time.sleep(delay_seconds)
                process_single_request()

        except Exception as e:
            logging.error(f"Error in upload_resume_task: {str(e)}")
            time.sleep(60)  # Wait a minute before retrying on error

# Start the background thread
thread = threading.Thread(target=upload_resume_task, daemon=True)
thread.start()

@app.route('/')
def health_check():
    logging.info("Health check endpoint accessed.")
    return jsonify({"status": "ResumeUploaderWeb is running"})

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=8000)