from flask import Flask, request, jsonify, send_from_directory
import logging
from azure.cosmos import CosmosClient, PartitionKey
from azure.communication.email import EmailClient
import os
import uuid
from datetime import datetime, timedelta

app = Flask(__name__)
logging.basicConfig(level=logging.INFO)

# Hardcoded configuration variables
COSMOS_ENDPOINT = "https://finalproj-cosmos.documents.azure.com:443/"
COSMOS_KEY = "jLfTrYuzKAoDAjOp7UYolqlXEIbcUJEdzmCMEO8Sfwm6BA2mG0bqByduTatCR7n1upaH2AZcCLJAACDbKOdx6A=="
ACS_CONNECTION_STRING = "endpoint=https://emailcommunicationfinalproj.unitedstates.communication.azure.com/;accesskey=6JMmFWB8pr293b3yDfmBNarjJrRyFXSI2iUuZoSkh48k8Ki3hEC4JQQJ99BDACULyCpciToOAAAAAZCS3FHT"
SENDER_EMAIL = "DoNotReply@2a1083c6-24da-442c-bef9-2befb55b094f.azurecomm.net"

# Log initialization
logging.info("Starting InterviewSchedulerApp...")

# Initialize Azure Cosmos DB client
try:
    client = CosmosClient(COSMOS_ENDPOINT, credential=COSMOS_KEY)
    logging.info("CosmosClient initialized successfully.")
except Exception as e:
    logging.error(f"Failed to initialize CosmosClient: {str(e)}")
    raise

# Initialize ACS Email client
try:
    email_client = EmailClient.from_connection_string(ACS_CONNECTION_STRING)
    logging.info("EmailClient initialized successfully.")
except Exception as e:
    logging.error(f"Failed to initialize EmailClient: {str(e)}")
    raise

# Initialize database and containers
try:
    database = client.get_database_client("FinalProjDb")
    logging.info("Connected to database FinalProjDb.")
    
    # Initialize Resumes container
    container = database.get_container_client("Resumes")
    logging.info("Connected to container Resumes.")

    # Create or get Emails container
    try:
        container_emails = database.create_container_if_not_exists(
            id="Emails",
            partition_key=PartitionKey(path="/id"),
            offer_throughput=400
        )
        logging.info("Emails container created or accessed successfully.")
    except Exception as e:
        logging.error(f"Failed to create or access Emails container: {str(e)}")
        container_emails = None
except Exception as e:
    logging.error(f"Failed to connect to database or containers: {str(e)}")
    database = None
    container = None
    container_emails = None

# Function to generate available interview time slots for the upcoming week
def generate_interview_slots():
    slots = []
    # Start from the current date
    current_date = datetime.now().date()
    # Find the next Monday from today
    days_to_monday = (7 - current_date.weekday()) % 7  # Days until next Monday
    if days_to_monday == 0:  # If today is Monday, start tomorrow
        days_to_monday = 7
    start_date = current_date + timedelta(days=days_to_monday)

    # Generate slots for Monday to Friday
    for day in range(5):  # Monday to Friday
        date = start_date + timedelta(days=day)
        # Slots from 9:00 AM to 5:00 PM, in 30-minute intervals
        for hour in range(9, 17):  # 9 AM to 5 PM
            for minute in (0, 30):
                slot_time = datetime(date.year, date.month, date.day, hour, minute)
                slots.append(slot_time)

    return slots

# Function to assign a time slot to a candidate
def assign_time_slot(used_slots):
    logging.info("Assigning a time slot...")
    available_slots = generate_interview_slots()
    logging.info(f"Generated {len(available_slots)} available time slots.")
    for slot in available_slots:
        slot_str = slot.strftime("%Y-%m-%d %H:%M:%S")
        if slot_str not in used_slots:
            logging.info(f"Assigned time slot: {slot_str}")
            return slot_str
    logging.warning("No available time slots found.")
    return None  # No available slots

@app.route('/schedule_interviews', methods=['POST'])
def schedule_interviews():
    logging.info('InterviewScheduler triggered via web app.')
    
    try:
        # Connect to Azure Cosmos DB
        logging.info("Connecting to Cosmos DB...")
        if container is None or container_emails is None:
            logging.error("Cosmos DB containers are not initialized.")
            return jsonify({"message": "Cosmos DB containers are not initialized.", "status": "error"}), 500

        # Query for shortlisted candidates
        logging.info("Querying for shortlisted candidates...")
        query = "SELECT * FROM c WHERE c.status = 'Shortlisted'"
        items = list(container.query_items(query=query, enable_cross_partition_query=True))
        logging.info(f"Found {len(items)} shortlisted candidates.")

        if not items:
            logging.info("No shortlisted candidates to process.")
            return jsonify({"message": "✅ Scheduled interviews for 0 candidates.", "status": "success"}), 200

        # Get all scheduled interviews from Emails container to determine used time slots
        used_slots = []
        try:
            scheduled_items = list(container_emails.query_items(
                query="SELECT * FROM c",
                enable_cross_partition_query=True
            ))
            for item in scheduled_items:
                if "interviewTime" in item:
                    used_slots.append(item["interviewTime"])
            logging.info(f"Found {len(used_slots)} used time slots.")
        except Exception as e:
            logging.error(f"Failed to query Emails container for used time slots: {str(e)}")
            used_slots = []  # Proceed with empty list to allow scheduling

        count = 0
        interview_schedules = []  # List to gather all interview schedules
        for item in items:
            if "email" not in item:
                logging.warning(f"Skipping item {item.get('id', 'unknown')} due to missing email.")
                continue

            # Assign a time slot
            interview_time = assign_time_slot(used_slots)
            if not interview_time:
                logging.warning(f"No available time slots for item {item['id']}. Skipping.")
                continue

            used_slots.append(interview_time)

            # Ensure interview_time is a clean string and sanitize it
            if not isinstance(interview_time, str):
                interview_time = str(interview_time)
            interview_time_safe = interview_time.replace('"', '').replace("'", '')

            # Send email via ACS
            logging.info(f"Sending email to {item['email']} with interview time {interview_time_safe}...")
            message = {
                "senderAddress": "DoNotReply@2a1083c6-24da-4a2c-bef9-2befb55b094f.azurecomm.net",
                "recipients": {
                    "to": [{"address": item["email"]}]
                },
                "content": {
                    "subject": "Interview Invitation",
                    "plainText": f"You have been shortlisted! Please confirm your availability for an interview scheduled on {interview_time_safe}.",
                    "html": (
                        "<html>"
                        "<body>"
                        "<h1>Interview Invitation</h1>"
                        "<p>You have been shortlisted! Please confirm your availability for an interview scheduled on <strong>" + interview_time_safe + "</strong>.</p>"
                        "</body>"
                        "</html>"
                    )
                }
            }
            poller = email_client.begin_send(message)
            result = poller.result()
            logging.info(f"Message sent: {result.message_id}")

            # Gather interview schedule
            interview_schedule = {
                "id": str(uuid.uuid4()),
                "candidateId": item["id"],
                "email": item["email"],
                "interviewTime": interview_time
            }
            interview_schedules.append(interview_schedule)

            # Update status and interview time in Resumes container
            logging.info(f"Updating status for item {item['id']} to 'Interview Scheduled' with time {interview_time}.")
            item["status"] = "Interview Scheduled"
            item["interviewTime"] = interview_time
            container.upsert_item(item)
            count += 1

        # Store all gathered interview schedules in the Emails container
        for schedule in interview_schedules:
            logging.info(f"Storing interview schedule for candidate {schedule['candidateId']} in Emails container.")
            container_emails.upsert_item(schedule)

        logging.info(f"Scheduled interviews for {count} candidates.")
        return jsonify({"message": f"✅ Scheduled interviews for {count} candidates.", "status": "success"}), 200
    except Exception as e:
        logging.error(f"Scheduler error: {str(e)}")
        return jsonify({"message": "Scheduling error occurred.", "status": "error"}), 500

@app.route('/')
def health_check():
    logging.info("Health check endpoint accessed.")
    return jsonify({"status": "App is running", "message": "Use /schedule_interviews to schedule interviews."})

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=8000)